# Push2Unlock (Android)
1. Open this folder in Android Studio (Koala or newer), let Gradle sync.
2. Run on a real phone (Android 8+; camera needed).
3. In the app: grant Usage Access + Overlay, pick apps to lock, set reward minutes and reps, tap Save & Start.
4. Opening a locked app launches the camera; complete the reps to unlock for the reward time.
Squats and pushups are counted via joint angles (ML Kit pose detection, on-device).
For squats, stand sideways or far enough back that hips-knees-ankles are visible.
