package com.example.push2unlock

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("p2u", Context.MODE_PRIVATE)
    fun blocked(c: Context): Set<String> = sp(c).getStringSet("blocked", emptySet()) ?: emptySet()
    fun setBlocked(c: Context, s: Set<String>) = sp(c).edit().putStringSet("blocked", s).apply()
    fun unlockUntil(c: Context) = sp(c).getLong("until", 0L)
    fun setUnlockUntil(c: Context, t: Long) = sp(c).edit().putLong("until", t).apply()
    fun rewardMin(c: Context) = sp(c).getInt("reward", 15)
    fun setRewardMin(c: Context, m: Int) = sp(c).edit().putInt("reward", m).apply()
    fun targetReps(c: Context) = sp(c).getInt("reps", 10)
    fun setTargetReps(c: Context, r: Int) = sp(c).edit().putInt("reps", r).apply()
}
