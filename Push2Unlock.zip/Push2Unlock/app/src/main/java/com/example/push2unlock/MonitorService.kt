package com.example.push2unlock

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class MonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastPkg = ""
    private val tick = object : Runnable {
        override fun run() { check(); handler.postDelayed(this, 1000) }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("p2u", "Push2Unlock", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "p2u")
            .setContentTitle("Push2Unlock is active")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock).build())
        handler.removeCallbacks(tick); handler.post(tick)
        return START_STICKY
    }

    private fun check() {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(now - 10_000, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) lastPkg = e.packageName
        }
        if (lastPkg in Prefs.blocked(this) && now > Prefs.unlockUntil(this)) {
            lastPkg = ""
            startActivity(Intent(this, ExerciseActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
        }
    }

    override fun onDestroy() { handler.removeCallbacks(tick); super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null
}
