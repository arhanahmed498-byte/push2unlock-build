package com.example.push2unlock

import android.Manifest
import android.app.AppOpsManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS), 1)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() }; root.addView(this) }

        root.addView(TextView(this).apply { text = "Push2Unlock"; textSize = 26f })
        btn("1. Grant Usage Access") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        btn("2. Grant Overlay permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        val reward = EditText(this).apply { setText(Prefs.rewardMin(this@MainActivity).toString()); hint = "Reward minutes (5-30)" }
        val reps = EditText(this).apply { setText(Prefs.targetReps(this@MainActivity).toString()); hint = "Reps required" }
        root.addView(TextView(this).apply { text = "Reward minutes" }); root.addView(reward)
        root.addView(TextView(this).apply { text = "Reps required" }); root.addView(reps)

        val chosen = Prefs.blocked(this).toMutableSet()
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        packageManager.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .distinct().filter { it.first != packageName }.sortedBy { it.second.lowercase() }
            .forEach { (pkg, label) ->
                list.addView(CheckBox(this).apply {
                    text = label; isChecked = pkg in chosen
                    setOnCheckedChangeListener { _, on -> if (on) chosen += pkg else chosen -= pkg }
                })
            }
        root.addView(TextView(this).apply { text = "Apps to lock"; textSize = 18f })
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))

        btn("Save & Start") {
            Prefs.setBlocked(this, chosen)
            Prefs.setRewardMin(this, (reward.text.toString().toIntOrNull() ?: 15).coerceIn(5, 30))
            Prefs.setTargetReps(this, (reps.text.toString().toIntOrNull() ?: 10).coerceIn(1, 100))
            if (!hasUsageAccess() || !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Grant steps 1 and 2 first", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, MonitorService::class.java))
                Toast.makeText(this, "Active", Toast.LENGTH_SHORT).show()
            }
        }
        btn("Stop") { stopService(Intent(this, MonitorService::class.java)) }
        setContentView(root)
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(AppOpsManager::class.java)
        return ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }
}
