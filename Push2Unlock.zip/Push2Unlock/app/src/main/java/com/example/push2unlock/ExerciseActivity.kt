package com.example.push2unlock

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.atan2

class ExerciseActivity : AppCompatActivity() {
    private val exec = Executors.newSingleThreadExecutor()
    private val detector = PoseDetection.getClient(
        PoseDetectorOptions.Builder().setDetectorMode(PoseDetectorOptions.STREAM_MODE).build())
    private lateinit var status: TextView
    private var squats = true
    private var down = false
    private var reps = 0
    private var target = 10
    private var done = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) { finish(); return }
        target = Prefs.targetReps(this)
        val preview = PreviewView(this)
        status = TextView(this).apply {
            textSize = 24f; setTextColor(Color.WHITE); setBackgroundColor(0xAA000000.toInt()); setPadding(30, 30, 30, 30)
            text = "Locked. Do $target squats to earn ${Prefs.rewardMin(this@ExerciseActivity)} min"
        }
        val toggle = Button(this).apply {
            text = "Switch to Pushups"
            setOnClickListener { squats = !squats; reps = 0; down = false
                text = if (squats) "Switch to Pushups" else "Switch to Squats"; update() }
        }
        val frame = FrameLayout(this)
        frame.addView(preview)
        frame.addView(status, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        frame.addView(toggle, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(frame)

        ProcessCameraProvider.getInstance(this).also { f ->
            f.addListener({
                val p = f.get()
                val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                val an = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                an.setAnalyzer(exec) { proxy -> analyze(proxy) }
                p.unbindAll()
                p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, pv, an)
            }, ContextCompat.getMainExecutor(this))
        }
    }

    @androidx.camera.core.ExperimentalGetImage
    private fun analyze(proxy: ImageProxy) {
        val img = proxy.image ?: run { proxy.close(); return }
        detector.process(InputImage.fromMediaImage(img, proxy.imageInfo.rotationDegrees))
            .addOnSuccessListener { pose ->
                val a = if (squats) avg(pose.getPoseLandmark(PoseLandmark.LEFT_HIP), pose.getPoseLandmark(PoseLandmark.LEFT_KNEE), pose.getPoseLandmark(PoseLandmark.LEFT_ANKLE),
                    pose.getPoseLandmark(PoseLandmark.RIGHT_HIP), pose.getPoseLandmark(PoseLandmark.RIGHT_KNEE), pose.getPoseLandmark(PoseLandmark.RIGHT_ANKLE))
                else avg(pose.getPoseLandmark(PoseLandmark.LEFT_SHOULDER), pose.getPoseLandmark(PoseLandmark.LEFT_ELBOW), pose.getPoseLandmark(PoseLandmark.LEFT_WRIST),
                    pose.getPoseLandmark(PoseLandmark.RIGHT_SHOULDER), pose.getPoseLandmark(PoseLandmark.RIGHT_ELBOW), pose.getPoseLandmark(PoseLandmark.RIGHT_WRIST))
                if (a != null) {
                    val lo = if (squats) 100.0 else 90.0
                    val hi = if (squats) 160.0 else 155.0
                    if (a < lo) down = true
                    else if (a > hi && down) { down = false; reps++; runOnUiThread { count() } }
                }
            }.addOnCompleteListener { proxy.close() }
    }

    private fun angle(a: PoseLandmark?, b: PoseLandmark?, c: PoseLandmark?): Double? {
        if (a == null || b == null || c == null) return null
        if (minOf(a.inFrameLikelihood, b.inFrameLikelihood, c.inFrameLikelihood) < 0.5f) return null
        var d = abs(Math.toDegrees((atan2(c.position.y - b.position.y, c.position.x - b.position.x) -
                atan2(a.position.y - b.position.y, a.position.x - b.position.x)).toDouble()))
        if (d > 180) d = 360 - d
        return d
    }

    private fun avg(a1: PoseLandmark?, b1: PoseLandmark?, c1: PoseLandmark?,
                    a2: PoseLandmark?, b2: PoseLandmark?, c2: PoseLandmark?): Double? {
        val l = listOfNotNull(angle(a1, b1, c1), angle(a2, b2, c2))
        return if (l.isEmpty()) null else l.average()
    }

    private fun update() { status.text = "${if (squats) "Squats" else "Pushups"}: $reps / $target" }

    private fun count() {
        update()
        if (reps >= target && !done) {
            done = true
            Prefs.setUnlockUntil(this, System.currentTimeMillis() + Prefs.rewardMin(this) * 60_000L)
            Toast.makeText(this, "Unlocked!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    override fun onDestroy() { detector.close(); exec.shutdown(); super.onDestroy() }
}
